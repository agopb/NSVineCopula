#' Data sets for illustrating the functions in NSVineCopula
#' @description Data sets for illustrating thr functions in NSVineCopula
#'
#' @format
#' \describe{
#'   \item{\code{$data}}{An \code{73 x 3} data set (format \code{data.frame}) with the uniform
#'   variables.}
#' }
#'
#' @examples
#' data(dataset)
#'
#' @author Quan Zhang
"dataset"


#' Density of a Nonstationary Bivariate Copula
#'
#' @param u numeric vectors of equal length with values in \eqn{[0,1]}.
#' @param family An integer defining the bivariate copula family: \cr
#' `0` = independence copula \cr
#' `1` = Gaussian copula \cr
#' `2` = Student t copula (t-copula) \cr
#' `3` = Clayton copula \cr
#' `4` = Gumbel copula \cr
#' `5` = Frank copula \cr
#' `6` = Joe copula \cr
#' `7` = BB1 copula \cr
#' `8` = BB6 copula \cr
#' `9` = BB7 copula \cr
#' `10` = BB8 copula \cr
#' `13` = rotated Clayton copula (180 degrees; ``survival Clayton'') \cr
#' `14` = rotated Gumbel copula (180 degrees; ``survival Gumbel'') \cr
#' `16` = rotated Joe copula (180 degrees; ``survival Joe'') \cr
#' `17` = rotated BB1 copula (180 degrees; ``survival BB1'')\cr
#' `18` = rotated BB6 copula (180 degrees; ``survival BB6'')\cr
#' `19` = rotated BB7 copula (180 degrees; ``survival BB7'')\cr
#' `20` = rotated BB8 copula (180 degrees; ``survival BB8'')\cr
#' `23` = rotated Clayton copula (90 degrees) \cr
#' `24` = rotated Gumbel copula (90 degrees) \cr
#' `26` = rotated Joe copula (90 degrees) \cr
#' `27` = rotated BB1 copula (90 degrees) \cr
#' `28` = rotated BB6 copula (90 degrees) \cr
#' `29` = rotated BB7 copula (90 degrees) \cr
#' `30` = rotated BB8 copula (90 degrees) \cr
#' `33` = rotated Clayton copula (270 degrees) \cr
#' `34` = rotated Gumbel copula (270 degrees) \cr
#' `36` = rotated Joe copula (270 degrees) \cr
#' `37` = rotated BB1 copula (270 degrees) \cr
#' `38` = rotated BB6 copula (270 degrees) \cr
#' `39` = rotated BB7 copula (270 degrees) \cr
#' `40` = rotated BB8 copula (270 degrees) \cr
#' `104` = Tawn type 1 copula \cr
#' `114` = rotated Tawn type 1 copula (180 degrees) \cr
#' `124` = rotated Tawn type 1 copula (90 degrees) \cr
#' `134` = rotated Tawn type 1 copula (270 degrees) \cr
#' `204` = Tawn type 2 copula \cr
#' `214` = rotated Tawn type 2 copula (180 degrees) \cr
#' `224` = rotated Tawn type 2 copula (90 degrees) \cr
#' `234` = rotated Tawn type 2 copula (270 degrees) \cr
#' @param par Copula parameter.
#'
#' @return A numeric vector of the nonstationary bivariate copula density.
#' @import VineCopula
#' @export
#' @author Quan Zhang
#' @examples
#'
#' data(dataset)
#' m1<-NSBiCopEst(dataset[,c(1,2)],familyset=c(1,2,3,4,5))
#' NSBiCopPDF(dataset[,c(1,2)],family=m1$family,par=m1$TVTP)
#'
NSBiCopPDF=function(u,family,par){
  pdf<-array(0,dim=c(nrow(par),1))
  for(i in 1:nrow(par)){
    pdf[i] <- .C("PDF_seperate_vec",
                 as.integer(family),
                 as.integer(1),
                 as.double(u[i,1]),
                 as.double(u[i,2]),
                 as.double(par[i,1]),
                 as.double(par[i,2]),
                 as.double(rep(0, 1)),
                 PACKAGE = "VineCopula")[[7]]
  }
  return(pdf)}

#' Parameters of a Nonstationary Bivariate Copula
#'
#' @param data numeric vectors of equal length with values in \eqn{[0,1]}.
#' @param theta parameters of ARMA function
#' @param rhobar  parameters of  bivariate copula
#' @param family An integer defining the bivariate copula family: \cr
#' `0` = independence copula \cr
#' `1` = Gaussian copula \cr
#' `2` = Student t copula (t-copula) \cr
#' `3` = Clayton copula \cr
#' `4` = Gumbel copula \cr
#' `5` = Frank copula \cr
#' `6` = Joe copula \cr
#' `7` = BB1 copula \cr
#' `8` = BB6 copula \cr
#' `9` = BB7 copula \cr
#' `10` = BB8 copula \cr
#' `13` = rotated Clayton copula (180 degrees; ``survival Clayton'') \cr
#' `14` = rotated Gumbel copula (180 degrees; ``survival Gumbel'') \cr
#' `16` = rotated Joe copula (180 degrees; ``survival Joe'') \cr
#' `17` = rotated BB1 copula (180 degrees; ``survival BB1'')\cr
#' `18` = rotated BB6 copula (180 degrees; ``survival BB6'')\cr
#' `19` = rotated BB7 copula (180 degrees; ``survival BB7'')\cr
#' `20` = rotated BB8 copula (180 degrees; ``survival BB8'')\cr
#' `23` = rotated Clayton copula (90 degrees) \cr
#' `24` = rotated Gumbel copula (90 degrees) \cr
#' `26` = rotated Joe copula (90 degrees) \cr
#' `27` = rotated BB1 copula (90 degrees) \cr
#' `28` = rotated BB6 copula (90 degrees) \cr
#' `29` = rotated BB7 copula (90 degrees) \cr
#' `30` = rotated BB8 copula (90 degrees) \cr
#' `33` = rotated Clayton copula (270 degrees) \cr
#' `34` = rotated Gumbel copula (270 degrees) \cr
#' `36` = rotated Joe copula (270 degrees) \cr
#' `37` = rotated BB1 copula (270 degrees) \cr
#' `38` = rotated BB6 copula (270 degrees) \cr
#' `39` = rotated BB7 copula (270 degrees) \cr
#' `40` = rotated BB8 copula (270 degrees) \cr
#' `104` = Tawn type 1 copula \cr
#' `114` = rotated Tawn type 1 copula (180 degrees) \cr
#' `124` = rotated Tawn type 1 copula (90 degrees) \cr
#' `134` = rotated Tawn type 1 copula (270 degrees) \cr
#' `204` = Tawn type 2 copula \cr
#' `214` = rotated Tawn type 2 copula (180 degrees) \cr
#' `224` = rotated Tawn type 2 copula (90 degrees) \cr
#' `234` = rotated Tawn type 2 copula (270 degrees) \cr
#' @param Call logical; if optim, return sum of log likelihood; if filtering, return
#'
#' @return An object describing the selected copula and its nonstationary parameter, includes the following information:
#' \item{\code{Loglilihood}}{sum of log likelihood}
#' \item{\code{beta}}{best parameter set of ARMA function }
#' \item{\code{TVTP}}{nonstationary paramters of selected copula }
#'
#' @import fGarch
#' @import mvtnorm
#' @export
#' @author Quan Zhang
#'
#' @examples
#'
#' data(dataset)
#' m1<-NSBiCopEst(dataset[,c(1,2)],familyset=c(1,2,3,4,5))
#' NSBiCopPar(dataset[,c(1,2)],theta=m1$beta,rhobar=m1$TVTP[1,],family=m1$family,Call="filtering")
#'
NSBiCopPar=function(data,theta,rhobar,family,Call){

  u = data[,1]
  v = data[,2]

  T = nrow(data)

  x=u
  y=v

  w=theta[1]
  a=theta[2]
  b=theta[3]

  w1=theta[1]
  a1=theta[2]
  b1=theta[3]
  w2=theta[4]
  a2=theta[5]
  b2=theta[6]

  kappa =matrix(-999,T,2)
  kappa[1,] = rhobar;

  if(family==1){

    x = qnorm(data[,1])
    y = qnorm(data[,2])
    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean((x[1:jj-1]*y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean((x[(jj-10):(jj-1)]*y[(jj-10):(jj-1)])))
      }
      kappa[jj,1] = 1.998/(1+exp(-kappa[jj,1]))-0.999
    }

  } else if (family==2){

    x = qstd(data[,1])
    y = qstd(data[,2])

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean((x[1:(jj-1)]*y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean((x[1:(jj-1)]*y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean((x[(jj-10):(jj-1)]*y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean((x[(jj-10):(jj-1)]*y[(jj-10):(jj-1)])))
      }
      kappa[jj,1] = 1.998/(1+exp(-kappa[jj,1]))-0.999
      kappa[jj,2]=2.001+kappa[jj,2]*kappa[jj,2]
    }

  } else if (family==3|family==13){

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1,1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1,1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1] = 28*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==4){

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1] = 1+16*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==5){
    for(jj in 2:T){
      if(jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=35*((1-exp(-kappa[jj,1]))/(1+exp(-kappa[jj,1])))

    }
  } else if (family==6|family==16){

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=1+29*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==7) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=7*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=1+6*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==8|family==18) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=1+5*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=1+7*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==9){

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=1+5*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=75*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==10|family==20) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=1+7*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==23|family==33) {

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-28*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==24|family==34) {

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-1-16*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==26|family==36) {

    for (jj in  2:T){
      if (jj<=10){
        kappa[jj,1] = w+ a*kappa[jj-1] + b*(mean(abs(x[1:jj-1]-y[1:jj-1])))
      }else{
        kappa[jj,1] = w+ (a*kappa[jj-1]) + b*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-1-29*(1/(1+exp(-kappa[jj,1])))
    }

  } else if (family==27|family==37) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-7*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=-1-6*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==28|family==38){

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-6*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=-1-7*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==29|family==39) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-1-5*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=-75*(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==30|family==40) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-1-7*(1/(1+exp(-kappa[jj,1])))
      kappa[jj,2]=-(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==104|family==114|family==204|family==214){

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=1+exp(-kappa[jj,1])
      kappa[jj,2]=(1/(1+exp(-kappa[jj,2])))
    }

  } else if (family==124|family==134|family==224|family==234) {

    for (jj in  2:n){
      if (jj<=10){
        kappa[jj,1] = w1+ a1*kappa[jj-1,1] + b1*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
        kappa[jj,2]= w2+ a2*kappa[jj-1,2] + b2*(mean(abs(x[1:(jj-1)]-y[1:(jj-1)])))
      }else{
        kappa[jj,1] = w1+ (a1*kappa[jj-1,1]) + b1*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
        kappa[jj,2] = w2+ (a2*kappa[jj-1,2]) + b2*(mean(abs(x[(jj-10):(jj-1)]-y[(jj-10):(jj-1)])))
      }
      kappa[jj,1]=-1-exp(-kappa[jj,1])
      kappa[jj,2]=(1/(1+exp(-kappa[jj,2])))
    }
  }

  if(sum(is.infinite(kappa))){
    CL<- -T*100
  }else if(sum(is.nan(kappa))){
    CL<- -T*100
  }else{
    CL=rep(0,T)

    CL=NSBiCopPDF(cbind(u,v),family,cbind(kappa[,1],kappa[,2]))

    CL = sum(log(CL))
  }

  CL<- -CL

  if (Call=="optim")
    return(CL)

  if (Call=="filtering")
  {
    specOut<-list(Loglikelihood=CL,beta=c(theta),TVTP=kappa)
    return(specOut)
  }
}


#' Selection and Maximum Likelihood Estimation of Nonstationary Bivariate Copula Families
#'
#' @param data Data vectors of equal length with values in \eqn{[0,1]}.
#' @param familyset Vector of nonstationary bivariate copula families to select from.
#' @param rotations logical; if TRUE, all rotations of the families in familyset are included.
#'
#' @return An object describing the selected family and nonstationary parameters, including the following entires:
#' \item{\code{family}}{selected family number}
#' \item{\code{AIC, BIC}}{Aikaike's Informaton Criterion, Bayesian's Informaton Criterion}
#' \item{\code{beta}}{the best paramter set of ARMA}
#' \item{\code{Loglikelihood}}{log likelihood}
#' \item{\code{TVTP}}{nonstationary parameters of selected copula}
#'
#' @import VineCopula
#' @import pracma
#' @export
#' @author Quan Zhang
#' @examples
#' data(dataset)
#' NSBiCopEst(dataset[,c(1,2)],familyset=c(1,2,3,4,5))
NSBiCopEst=function(data,familyset,rotations=FALSE){

  lower =rep(-5,6)
  upper =rep(5,6)

  theta<-c(0,0,0,0,0,0)

  v3<-VineCopula::BiCopSelect(data[,1],data[,2],familyset=familyset,rotations=rotations)

  if(v3$family==1){
    theta<-c(log((v3$par+1)/(1-v3$par)),0,0,0,0,0)
  } else if (v3$family==2) {
    theta<-c(log((v3$par+1)/(1-v3$par)),0,0,sqrt(v3$par2-2),0,0)
  } else if (v3$family==3|v3$family==13) {
    theta<-c(log(v3$par/(28-v3$par)),0,0,0,0,0)
  } else if (v3$family==4){
    theta<-c(log((v3$par-1)/(17-v3$par)),0,0,0,0,0)
  } else if (v3$family==5){
    theta<-c(v3$par,0,0,0,0,0)
  } else if (v3$family==6|v3$family==16){
    theta<-c(log((v3$par-1)/(30-v3$par)),0,0,0,0,0)
  } else if (v3$family==7) {
    theta<-c(log(v3$par/(7-v3$par)),0,0,log((v3$par-1)/(7-v3$par)),0,0)
  } else if (v3$family==8|v3$family==18){
    theta<-c(log((v3$par-1)/(6-v3$par)),0,0,log(v3$par/(8-v3$par)),0,0)
  } else if (v3$family==9){
    theta<-c(log((v3$par-1)/(6-v3$par)),0,0,log(v3$par/(75-v3$par)),0,0)
  } else if (v3$family==10|v3$family==20){
    theta<-c(log((v3$par-1)/(8-v3$par)),0,0,log(v3$par/(1-v3$par)),0,0)
  } else if (v3$family==23|v3$family==33){
    theta<-c(log(v3$par/(-28-v3$par)),0,0,0,0,0)
  } else if (v3$family==24|v3$family==34){
    theta<-c(log((1-v3$par)/(v3$par-17)),0,0,0,0,0)
  } else if (v3$family==26|v3$family==36){
    theta<-c(log((1-v3$par)/(v3$par-30)),0,0,0,0,0)
  } else if (v3$family==27|v3$family==37){
    theta<-c(log(v3$par/(-7-v3$par)),0,0,log((v3$par+1)/(-7-v3$par)),0,0)
  } else if (v3$family==28|v3$family==38){
    theta<-c(log(v3$par/(-6-v3$par)),0,0,log((v3$par+1)/(-8-v3$par)),0,0)
  } else if (v3$family==29|v3$family==39){
    theta<-c(log((v3$par+1)/(-6-v3$par)),0,0,log(v3$par/(-75-v3$par)),0,0)
  } else if (v3$family==30|v3$family==40){
    theta<-c(log((v3$par+1)/(-8-v3$par)),0,0,log(v3$par/(-1-v3$par)),0,0)
  } else if (v3$family==104|v3$family==114|v3$family==204|v3$family==214){
    theta<-c(log(1/(v3$par-1)),0,0,log(v3$par/(1-v3$par)),0,0)
  } else if (v3$family==124|v3$family==134|v3$family==224|v3$family==234){
    theta<-c(log(1/(1-v3$par)),0,0,log(v3$par/(1-v3$par)),0,0)
  }

  if(v3$par2==0){
    model<-optim(theta,NSBiCopPar,data=data,rhobar=cbind(v3$par,v3$par2),family=v3$family,Call="optim",
                 control = list(maxit=100000,fnscale=1),method="L-BFGS-B",
                 lower =lower,upper =upper, hessian=TRUE)
  } else {
    model<-fmincon(theta,NSBiCopPar,data=data,rhobar=cbind(v3$par,v3$par2),family=v3$family,Call="optim",
                   tol=1e-03,maxiter=100000,lb=lower,ub=upper)
  }

  print(model$par)

  model$value<- -model$value
  n<-nrow(data)
  coef<- model$par

  n1<-length(which(model$par!=0))/3

  BIC= -2*model$value+ (log(n)*n1)
  AIC = -2*model$value + 2*n1

  rhot=NSBiCopPar(theta=coef,data=data,rhobar=cbind(v3$par,v3$par2),family=v3$family,Call="filtering")$TVTP

  output=list(
    family=v3$family,
    beta=coef,
    AIC=AIC,
    BIC=BIC,
    Loglikelihood=model$value,
    TVTP=rhot
  )
  output
}

#' Conditional probabilities from an Nonstationary Vine Copula
#'
#' @param data A data matrix. The data of the conditioning variable have to copy the last column of this matrix.
#' @param u numeric vectors  with values in \eqn{[0,1]}.
#' @param familyset Vector of nonstationary bivariate copula families to select from.
#' @param Matrix Lower (or upper) triangular d x d matrix that defines the R-vine tree structure.
#' @param selectioncrit Character indicating the criterion for pair-copula selection. Possible choices are "AIC" (default) and "BIC".
#' @param indeptest Logical; whether a hypothesis test for the independence of
#' \code{u1} and \code{u2} is performed before bivariate copula selection
#' (default: \code{indeptest = FALSE}; see \code{BiCopIndTest}).  The
#' independence copula is chosen for a (conditional) pair if the null
#' hypothesis of independence cannot be rejected.
#' @param level numeric; significance level of the independence test (default:
#' \code{level = 0.05}).
#' @param trunclevel integer; level of truncation.
#' @param weights Numerical; weights for each observation (optional).
#' @param rotations logical; if TRUE, all rotations of the families in familyset are included.
#' @param se Logical; whether standard errors are estimated (default: se = FALSE).
#' @param presel Logical; whether to exclude families before fitting based on symmetry properties of the data. Makes the selection about 30\ (on average), but may yield slightly worse results in few special cases.
#' @param method indicates the estimation method: either maximum
#' likelihood estimation (`method = "mle"`; default) or inversion of
#' Kendall's tau (`method = "itau"`). For `method = "itau"` only
#' one parameter families and the Student t copula can be used (`family =
#' 1,2,3,4,5,6,13,14,16,23,24,26,33,34` or `36`). For the t-copula,
#' `par2` is found by a crude profile likelihood optimization over the
#' interval (2, 10].
#' @param cores integer; if `cores > 1`, estimation will be parallelized
#' within each tree (using [foreach::foreach()]). Note that
#' parallelization causes substantial overhead and may be slower than
#' single-threaded computation when dimension, sample size, or family set are
#' small or `method = "itau"`
#'
#' @return An object describing the conditional probabilities from nonstationary vine Copula,
#' including the following information:
#' An [RVineMatrix()] object with the selected families
#' (`family`) as well as sequentially
#' estimated parameters stored in `par` and `par2`.
#' \item{nobs}{number of observations,}
#' \item{logLik, pair.logLik}{log likelihood (overall and pairwise)}
#' \item{AIC, pair.AIC}{Aikaike's Informaton Criterion (overall and pairwise),}
#' \item{BIC, pair.BIC}{Bayesian's Informaton Criterion (overall and pairwise),}
#' \item{emptau}{matrix of empirical values of Kendall's tau,}
#' \item{NSParam, NSParam2}{nonstationary parameters matrix}
#' \item{NSfamily}{pair-copula family matrix with nonstationary values}
#' \item{ConPro}{Conditional probabilities of variable}
#' \item{NSAIC, NSBIC}{AIC and BIC value with nonstationary values}
#'
#' @import VineCopula
#' @import CDVineCopulaConditional
#' @export
#' @author Quan Zhang
#' @examples
#'
#' data(dataset)
#' ze1<-CDVineCopulaConditional::CDVineCondListMatrices(dataset, Nx=2, type = "CVine-DVine")
#' v1<-list()
#' l=1
#' AIC1<-vector()
#' for(j in 1:2){
#'   for(k in 1:2){
#'     rvm1<-VineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=ze1[[j]][[k]])
#'     v1[[l]]<-rvm1
#'     l<-l+1
#'     AIC1<-cbind(AIC1,rvm1$AIC)
#'   }
#' }
#' n1<-which(AIC1==min(AIC1))
#' rvm<-v1[[n1[1]]]
#' m2<-NSVineCopCond(dataset,c(0.1,0.1,0.1),familyset=c(1,2,3,4,5),rvm$Matrix)

NSVineCopCond <- function(data, u,familyset = NA, Matrix, selectioncrit = "AIC",
                          indeptest = FALSE, level = 0.05, trunclevel = NA,
                          weights = NA, rotations = FALSE, se = FALSE,
                          presel = TRUE, method = "mle", cores = 1) {

  if (!(selectioncrit %in% c("AIC", "BIC", "logLik")))
    stop("Selection criterion not implemented.")
  if (level < 0 & level > 1)
    stop("Significance level has to be between 0 and 1.")

  d <- n <- ncol(data)
  N <- nrow(data)

  varnames <- colnames(data)
  if (is.na(trunclevel))
    trunclevel <- d

  types <- familyset
  if (trunclevel == 0)
    types <- 0

  M <- Matrix
  Mold <- M
  o <- diag(M)
  M <- VineCopula:::reorderRVineMatrix(M)
  data <- data[, o[length(o):1]]

  u1<-rep(u,N)
  u1<-t(matrix(u1,nrow=length(u),ncol=N))

  u1<-u1[,o[length(o):1]]

  MaxMat <- VineCopula:::createMaxMat(M)
  CondDistr <- VineCopula:::neededCondDistr(M)

  Types   <- matrix(0, d, d)
  Params  <- matrix(0, d, d)
  Params2 <- matrix(0, d, d)
  Ses     <- matrix(0, d, d)
  Se2s    <- matrix(0, d, d)
  pvals   <- matrix(0, d, d)
  nobs    <- matrix(0, d, d)
  logLiks <- matrix(0, d, d)
  NSParam<-array(0,dim=c(d,d,N))
  NSParam2<-array(0,dim=c(d,d,N))
  NSTypes<-matrix(0, d, d)

  V <- list()
  V$direct <- array(NA, dim = c(d, N))
  V$indirect <- array(NA, dim = c(d, N))
  V$direct <- t(data[, d:1])
  V$direct_u<- t(u1[,d:1])
  V$indirect_u <- array(NA,dim=c(d,N))
  V$value1<-array(NA, dim = c(N, 1))
  V$value2<-array(NA, dim = c(N, 1))
  V$value3<-array(NA, dim = c(N, 1))

  V$z1_TF<-array(FALSE,dim=c(d,1))
  V$z2_TF<-array(FALSE,dim=c(d,1))

  V$NSdirect<-array(NA, dim = c(d, N))
  V$NSindirect<-array(NA, dim = c(d, N))
  V$NSdirect<-t(data[, d:1])
  V$NSPar<-array(NA,dim=c(d,n))

  if (cores != 1 | is.na(cores)) {
    if (is.na(cores))
      cores <- max(1, detectCores() - 1)
    if (cores > 1) {
      cl <- makePSOCKcluster(cores)
      setDefaultCluster(cl)
      on.exit(try(stopCluster(cl), silent = TRUE))
    }
  }

  warn <- NULL
  CL<-0
  for (k in d:2) {

    res.k<-list()

    for(i in 1:(k-1)) {
      if (k > i) {

        m <- MaxMat[k, i]
        zr1 <- V$direct[i, ]
        zr1_u <-V$direct_u[i,]
        zr11<-V$NSdirect[i,]

        if(i==d){
          V$z1_TF[i,1]<-TRUE
        }

        if (m == M[k, i]) {
          zr2 <-V$direct[(d - m + 1), ]
          zr2_u<-V$direct_u[(d - m + 1), ]
          zr22<-V$NSdirect[(d-m+1),]

          if((d - m + 1)==d){
            V$z2_TF[(d - m + 1),1]<-TRUE
          }
        } else {
          zr2 <-V$indirect[(d - m + 1), ]
          zr2_u <-V$indirect_u[(d - m + 1), ]
          zr22<-V$NSindirect[(d-m+1),]

          if((d - m + 1)==d){
            V$z2_TF[(d - m + 1),1]<-FALSE
          }

        }

        if (trunclevel <= (d-k))
          familyset <- 0

        na.ind <- which(is.na(zr1 + zr2))
        if (length(na.ind) >= length(zr1) - 10 ||
            (length(familyset) == 1 && familyset == 0)) {
          cfit <- BiCop(0)
          cfit$se  <- NA
          cfit$se2 <- NA
          cfit$nobs   <- 0
          cfit$logLik <- 0
          cfit$AIC    <- 0
          cfit$BIC    <- 0
          cfit$emptau <- NA
          cfit$p.value.indeptest <- NA
          if (length(na.ind) >= length(zr1) - 10) {
            warn <- paste("Insufficient data for at least one pair.",
                          "Independence has been selected automatically.")
          }
        } else {
          cfit <- suppressWarnings(VineCopula::BiCopSelect(u1 = zr2,
                                               u2 = zr1,
                                               familyset = familyset,
                                               selectioncrit = selectioncrit,
                                               indeptest = indeptest,
                                               level = level,
                                               weights = weights,
                                               rotations = rotations,
                                               se = se,
                                               presel = presel,
                                               method = method))

          data1<-cbind(zr22,zr11)
          rhobar1<-cbind(cfit$par,cfit$par2)
          family1<-cfit$family
          cfit_NSVineCopPar<-NSBiCopEst(data=data1,familyset=familyset)
          CL<-CL+cfit_NSVineCopPar$Loglikelihood
          warn <- NULL
        }

        direct <- indirect <- NULL
        NSdirect<- NSindirect <- array(NA, dim = c(1, N))
        direct_u <- indirect_u <- array(NA, dim = c(1, N))
        if (CondDistr$direct[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            direct <- zr1
          } else {
            direct <- suppressWarnings(VineCopula::BiCopHfunc1(zr2,
                                                   zr1,
                                                   cfit,
                                                   check.pars = FALSE))

            if(V$z1_TF[i,1]==TRUE|V$z2_TF[(d - m + 1),1]==TRUE){
              V$z1_TF[i,1]=TRUE
            }

            for(iii in 1:N){
              NSdirect[1,iii]<-.C("Hfunc1_vec",
                                  as.integer(cfit_NSVineCopPar$family),
                                  as.integer(1),
                                  as.double(zr11[iii]),
                                  as.double(zr22[iii]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                  as.double(rep(0, 1)),
                                  PACKAGE = "VineCopula")[[7]]
            }

            for(iii in 1:N){
              direct_u[1,iii]<-.C("Hfunc1_vec",
                                  as.integer(cfit_NSVineCopPar$family),
                                  as.integer(1),
                                  as.double(zr1_u[iii]),
                                  as.double(zr2_u[iii]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                  as.double(rep(0, 1)),
                                  PACKAGE = "VineCopula")[[7]]
            }

          }
        }


        if (CondDistr$indirect[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            indirect <- zr2
          } else {
            indirect <- suppressWarnings(VineCopula::BiCopHfunc2(zr2,
                                                     zr1,
                                                     cfit,
                                                     check.pars = FALSE))

            if(V$z1_TF[i,1]==TRUE|V$z2_TF[(d - m + 1),1]==TRUE){
              V$z2_TF[i,1]=TRUE
            } else {
              V$z2_TF[i,1]=FALSE
            }

            for(iii in 1:N){
              NSindirect[1,iii]<-.C("Hfunc2_vec",
                                    as.integer(cfit_NSVineCopPar$family),
                                    as.integer(1),
                                    as.double(zr22[iii]),
                                    as.double(zr11[iii]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                    as.double(rep(0, 1)),
                                    PACKAGE = "VineCopula")[[7]]
            }

            for(iii in 1:N){
              indirect_u[1,iii]<-.C("Hfunc2_vec",
                                    as.integer(cfit_NSVineCopPar$family),
                                    as.integer(1),
                                    as.double(zr2_u[iii]),
                                    as.double(zr1_u[iii]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                    as.double(rep(0, 1)),
                                    PACKAGE = "VineCopula")[[7]]
            }

          }
        }

        if(k==2&i==1){
          for(iii in 1:N){

            if(V$z1_TF[i,1]==TRUE&V$z2_TF[(d - m + 1),1]==TRUE){
              print("Wrong!")
            } else if (V$z1_TF[i,1]==TRUE&(V$z2_TF[(d - m + 1),1]==FALSE|is.na(V$z2_TF[(d - m + 1),1]))){
              V$value3[iii,1]<-.C("Hfunc1_vec",
                                  as.integer(cfit_NSVineCopPar$family),
                                  as.integer(1),
                                  as.double(zr1_u[iii]),
                                  as.double(zr2_u[iii]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                  as.double(rep(0, 1)),
                                  PACKAGE = "VineCopula")[[7]]
            } else if (V$z2_TF[(d - m + 1),1]==TRUE&(V$z1_TF[i,1]==FALSE|is.na(V$z1_TF[i,1]))){
              V$value3[iii,1]<-.C("Hfunc1_vec",
                                  as.integer(cfit_NSVineCopPar$family),
                                  as.integer(1),
                                  as.double(zr2_u[iii]),
                                  as.double(zr1_u[iii]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                  as.double(rep(0, 1)),
                                  PACKAGE = "VineCopula")[[7]]
            }

          }
        }

        res.k[[i]]<-list(direct = direct,
                         indirect = indirect,
                         cfit = cfit,
                         warn = warn,
                         cfit_NSVineCopPar=cfit_NSVineCopPar,
                         NSdirect=NSdirect,
                         NSindirect=NSindirect,
                         direct_u=direct_u,
                         indirect_u=indirect_u)

        ## return results
      } else {
        list(cfit = BiCop(0, 0))
      }
    }

    for (i in seq_len(k - 1)) {
      Types[k, i]   <- res.k[[i]]$cfit$family
      NSTypes[k,i] <- res.k[[i]]$cfit_NSVineCopPar$family
      Params[k, i]  <- res.k[[i]]$cfit$par
      Params2[k, i] <- res.k[[i]]$cfit$par2
      tmpse         <- res.k[[i]]$cfit$se
      Ses[k, i]     <- ifelse(is.null(tmpse), NA, tmpse)
      tmpse2        <- res.k[[i]]$cfit$se2
      Se2s[k, i]    <- ifelse(is.null(tmpse2), NA, tmpse2)
      pvals[k, i]   <- res.k[[i]]$cfit$p.value.indeptest
      logLiks[k, i] <- res.k[[i]]$cfit$logLik
      NSParam[k,i,]<-res.k[[i]]$cfit_NSVineCopPar$TVTP[,1]
      NSParam2[k,i,]<-res.k[[i]]$cfit_NSVineCopPar$TVTP[,2]
      if (!is.null(res.k[[i]]$warn))
        warn <- res.k[[i]]$warn
      if (!is.null(res.k[[i]]$direct)){
        V$direct[i, ] <- res.k[[i]]$direct
        V$NSdirect[i,]<-res.k[[i]]$NSdirect
        V$direct_u[i,]<-res.k[[i]]$direct_u
      }
      if (!is.null(res.k[[i]]$indirect)){
        V$indirect[i, ] <- res.k[[i]]$indirect
        V$NSindirect[i,]<-res.k[[i]]$NSindirect
        V$indirect_u[i,]<-res.k[[i]]$indirect_u
      }
    }
  }

  .RVM <- VineCopula::RVineMatrix(Mold,
                      family = Types,
                      par = Params,
                      par2 = Params2,
                      names = varnames)
  if (se == TRUE) {
    .RVM$se <- Ses
    .RVM$se2 <- Se2s
  }
  .RVM$nobs <- N
  revo <- sapply(1:d, function(i) which(o[length(o):1] == i))
  like <- suppressWarnings(VineCopula::RVineLogLik(data[, revo], .RVM, calculate.V = FALSE))
  .RVM$logLik <- like$loglik
  .RVM$pair.logLik <- logLiks
  npar <- length(which(.RVM$par!=0))+length(which(.RVM$par2!=0))
  .RVM$AIC <- -2 * like$loglik + 2 * npar
  .RVM$BIC <- -2 * like$loglik + log(N) * npar
  .RVM$p.value.indeptest <- pvals

  .RVM[[length(.RVM)+1]]<-NSParam
  .RVM[[length(.RVM)+1]]<-NSParam2
  .RVM[[length(.RVM)+1]]<-NSTypes
  .RVM[[length(.RVM)+1]]<-V$value3
  .RVM[[length(.RVM)+1]]<- -2 * CL + 2 * npar
  .RVM[[length(.RVM)+1]]<- -2 * CL + log(N) * npar

  name1<-names(.RVM)
  name1[(length(.RVM)-5):length(.RVM)]<-c("NSParam","NSParam2","NSfamily","ConPro","NSAIC","NSBIC")
  names(.RVM)<-name1
  return(.RVM)
}

#' Parameter Estimation for Nonstationary Vine Copula
#'
#' @param data A data matrix. The data of the conditioning variable have to copy the last column of this matrix.
#' @param familyset Vector of nonstationary bivariate copula families to select from.
#' @param Matrix Lower (or upper) triangular d x d matrix that defines the R-vine tree structure.
#' @param selectioncrit Character indicating the criterion for pair-copula selection. Possible choices are "AIC" (default) and "BIC".
#' @param indeptest Logical; whether a hypothesis test for the independence of
#' \code{u1} and \code{u2} is performed before bivariate copula selection
#' (default: \code{indeptest = FALSE}; see \code{BiCopIndTest}).  The
#' independence copula is chosen for a (conditional) pair if the null
#' hypothesis of independence cannot be rejected.
#' @param level numeric; significance level of the independence test (default:
#' \code{level = 0.05}).
#' @param trunclevel integer; level of truncation.
#' @param weights Numerical; weights for each observation (optional).
#' @param rotations logical; if TRUE, all rotations of the families in familyset are included.
#' @param se Logical; whether standard errors are estimated (default: se = FALSE).
#' @param presel Logical; whether to exclude families before fitting based on symmetry properties of the data. Makes the selection about 30\ (on average), but may yield slightly worse results in few special cases.
#' @param method indicates the estimation method: either maximum
#' likelihood estimation (`method = "mle"`; default) or inversion of
#' Kendall's tau (`method = "itau"`). For `method = "itau"` only
#' one parameter families and the Student t copula can be used (`family =
#' 1,2,3,4,5,6,13,14,16,23,24,26,33,34` or `36`). For the t-copula,
#' `par2` is found by a crude profile likelihood optimization over the
#' interval (2, 10].
#' @param cores integer; if `cores > 1`, estimation will be parallelized
#' within each tree (using [foreach::foreach()]). Note that
#' parallelization causes substantial overhead and may be slower than
#' single-threaded computation when dimension, sample size, or family set are
#' small or `method = "itau"`
#'
#' @return An object describing the selected family and nonstationary parameters,
#' including the following information:
#' #' An [RVineMatrix()] object with the selected families
#' (`family`) as well as sequentially
#' estimated parameters stored in `par` and `par2`.
#' \item{nobs}{number of observations,}
#' \item{logLik, pair.logLik}{log likelihood (overall and pairwise)}
#' \item{AIC, pair.AIC}{Aikaike's Informaton Criterion (overall and pairwise),}
#' \item{BIC, pair.BIC}{Bayesian's Informaton Criterion (overall and pairwise),}
#' \item{emptau}{matrix of empirical values of Kendall's tau,}
#' \item{NSParam, NSParam2}{nonstationary parameters matrix}
#' \item{NSfamily}{pair-copula family matrix with nonstationary values}
#' \item{NSAIC, NSBIC}{AIC and BIC value with nonstationary values}
#'
#' @import VineCopula
#' @export
#' @author Quan Zhang
#'
#' @examples
#' data(dataset)
#' ze1<-CDVineCopulaConditional::CDVineCondListMatrices(dataset, Nx=2, type = "CVine-DVine")
#' v1<-list()
#' l=1
#' AIC1<-vector()
#' for(j in 1:2){
#'   for(k in 1:2){
#'     rvm1<-VineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=ze1[[j]][[k]])
#'     v1[[l]]<-rvm1
#'     l<-l+1
#'     AIC1<-cbind(AIC1,rvm1$AIC)
#'   }
#' }
#' n1<-which(AIC1==min(AIC1))
#' rvm<-v1[[n1[1]]]
#' m2<-NSVineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=rvm$Matrix)
#'
NSVineCopPar <- function(data, familyset = NA, Matrix, selectioncrit = "AIC",
                         indeptest = FALSE, level = 0.05, trunclevel = NA,
                         weights = NA, rotations = FALSE, se = FALSE,
                         presel = TRUE, method = "mle", cores = 1) {
  if (!(selectioncrit %in% c("AIC", "BIC", "logLik")))
    stop("Selection criterion not implemented.")
  if (level < 0 & level > 1)
    stop("Significance level has to be between 0 and 1.")

  d <- n <- ncol(data)
  N <- nrow(data)
  varnames <- colnames(data)
  if (is.na(trunclevel))
    trunclevel <- d

  types <- familyset
  if (trunclevel == 0)
    types <- 0

  M <- Matrix
  Mold <- M
  o <- diag(M)
  M <- VineCopula:::reorderRVineMatrix(M)
  data <- data[, o[length(o):1]]

  MaxMat <- VineCopula:::createMaxMat(M)
  CondDistr <- VineCopula:::neededCondDistr(M)

  Types   <- matrix(0, d, d)
  Params  <- matrix(0, d, d)
  Params2 <- matrix(0, d, d)
  Ses     <- matrix(0, d, d)
  Se2s    <- matrix(0, d, d)
  pvals   <- matrix(0, d, d)
  nobs    <- matrix(0, d, d)
  logLiks <- matrix(0, d, d)
  NSParam<-array(0,dim=c(d,d,N))
  NSParam2<-array(0,dim=c(d,d,N))
  NSTypes<-matrix(0, d, d)

  V <- list()
  V$direct <- array(NA, dim = c(d, N))
  V$indirect <- array(NA, dim = c(d, N))
  V$direct <- t(data[, d:1])

  V$NSdirect<-array(NA, dim = c(d, N))
  V$NSindirect<-array(NA, dim = c(d, N))
  V$NSdirect<-t(data[, d:1])
  V$NSPar<-array(NA,dim=c(d,n))

  if (cores != 1 | is.na(cores)) {
    if (is.na(cores))
      cores <- max(1, detectCores() - 1)
    if (cores > 1) {
      cl <- makePSOCKcluster(cores)
      setDefaultCluster(cl)
      on.exit(try(stopCluster(cl), silent = TRUE))
    }
  }

  CL<-0
  warn <- NULL
  for (k in d:2) {

    res.k<-list()

    for(i in 1:(k-1)) {
      if (k > i) {

        m <- MaxMat[k, i]
        zr1 <- V$direct[i, ]
        zr11<-V$NSdirect[i,]

        if (m == M[k, i]) {
          zr2 <-V$direct[(d - m + 1), ]
          zr22<-V$NSdirect[(d-m+1),]
        } else {
          zr2 <-V$indirect[(d - m + 1), ]
          zr22<-V$NSindirect[(d-m+1),]
        }

        if (trunclevel <= (d-k))
          familyset <- 0

        na.ind <- which(is.na(zr1 + zr2))
        if (length(na.ind) >= length(zr1) - 10 ||
            (length(familyset) == 1 && familyset == 0)) {
          cfit <- BiCop(0)
          cfit$se  <- NA
          cfit$se2 <- NA
          cfit$nobs   <- 0
          cfit$logLik <- 0
          cfit$AIC    <- 0
          cfit$BIC    <- 0
          cfit$emptau <- NA
          cfit$p.value.indeptest <- NA
          if (length(na.ind) >= length(zr1) - 10) {
            warn <- paste("Insufficient data for at least one pair.",
                          "Independence has been selected automatically.")
          }
        } else {
          cfit <- suppressWarnings(VineCopula::BiCopSelect(u1 = zr2,
                                               u2 = zr1,
                                               familyset = familyset,
                                               selectioncrit = selectioncrit,
                                               indeptest = indeptest,
                                               level = level,
                                               weights = weights,
                                               rotations = rotations,
                                               se = se,
                                               presel = presel,
                                               method = method))

          data1<-cbind(zr22,zr11)
          rhobar1<-cbind(cfit$par,cfit$par2)
          family1<-cfit$family
          cfit_NSVineCopPar<-NSBiCopEst(data=data1,familyset=familyset)
          CL<-CL+cfit_NSVineCopPar$Loglikelihood
          warn <- NULL
        }

        direct <- indirect <- NULL
        NSdirect<- NSindirect <- array(NA, dim = c(1, N))
        if (CondDistr$direct[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            direct <- zr1
          } else {
            direct <- suppressWarnings(VineCopula::BiCopHfunc1(zr2,
                                                   zr1,
                                                   cfit,
                                                   check.pars = FALSE))

            for(iii in 1:N){
              NSdirect[1,iii]<-.C("Hfunc1_vec",
                                  as.integer(cfit_NSVineCopPar$family),
                                  as.integer(1),
                                  as.double(zr11[iii]),
                                  as.double(zr22[iii]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                  as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                  as.double(rep(0, 1)),
                                  PACKAGE = "VineCopula")[[7]]
            }
          }
        }


        if (CondDistr$indirect[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            indirect <- zr2
          } else {
            indirect <- suppressWarnings(VineCopula::BiCopHfunc2(zr2,
                                                     zr1,
                                                     cfit,
                                                     check.pars = FALSE))
            for(iii in 1:N){
              NSindirect[1,iii]<-.C("Hfunc2_vec",
                                    as.integer(cfit_NSVineCopPar$family),
                                    as.integer(1),
                                    as.double(zr22[iii]),
                                    as.double(zr11[iii]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,1]),
                                    as.double(cfit_NSVineCopPar$TVTP[iii,2]),
                                    as.double(rep(0, 1)),
                                    PACKAGE = "VineCopula")[[7]]
            }
          }
        }

        res.k[[i]]<-list(direct = direct,
                         indirect = indirect,
                         cfit = cfit,
                         warn = warn,
                         cfit_NSVineCopPar=cfit_NSVineCopPar,
                         NSdirect=NSdirect,
                         NSindirect=NSindirect)

      } else {
        list(cfit = BiCop(0, 0))
      }
    }

    for (i in seq_len(k - 1)) {
      Types[k, i]   <- res.k[[i]]$cfit$family
      NSTypes[k,i] <- res.k[[i]]$cfit_NSVineCopPar$family
      Params[k, i]  <- res.k[[i]]$cfit$par
      Params2[k, i] <- res.k[[i]]$cfit$par2
      tmpse         <- res.k[[i]]$cfit$se
      Ses[k, i]     <- ifelse(is.null(tmpse), NA, tmpse)
      tmpse2        <- res.k[[i]]$cfit$se2
      Se2s[k, i]    <- ifelse(is.null(tmpse2), NA, tmpse2)
      pvals[k, i]   <- res.k[[i]]$cfit$p.value.indeptest
      logLiks[k, i] <- res.k[[i]]$cfit$logLik
      NSParam[k,i,]<-res.k[[i]]$cfit_NSVineCopPar$TVTP[,1]
      NSParam2[k,i,]<-res.k[[i]]$cfit_NSVineCopPar$TVTP[,2]
      if (!is.null(res.k[[i]]$warn))
        warn <- res.k[[i]]$warn
      if (!is.null(res.k[[i]]$direct)){
        V$direct[i, ] <- res.k[[i]]$direct
        V$NSdirect[i,]<-res.k[[i]]$NSdirect
      }
      if (!is.null(res.k[[i]]$indirect)){
        V$indirect[i, ] <- res.k[[i]]$indirect
        V$NSindirect[i,]<-res.k[[i]]$NSindirect
      }

    }
  }

  .RVM <- VineCopula::RVineMatrix(Mold,
                      family = Types,
                      par = Params,
                      par2 = Params2,
                      names = varnames)
  if (se == TRUE) {
    .RVM$se <- Ses
    .RVM$se2 <- Se2s
  }
  .RVM$nobs <- N
  revo <- sapply(1:d, function(i) which(o[length(o):1] == i))
  like <- suppressWarnings(VineCopula::RVineLogLik(data[, revo], .RVM, calculate.V = FALSE))
  .RVM$logLik <- like$loglik
  .RVM$pair.logLik <- logLiks
  npar <- length(which(.RVM$par!=0))+length(which(.RVM$par2!=0))
  .RVM$AIC <- -2 * like$loglik + 2 * npar
  .RVM$BIC <- -2 * like$loglik + log(N) * npar
  .RVM$p.value.indeptest <- pvals

  .RVM[[length(.RVM)+1]]<-NSParam
  .RVM[[length(.RVM)+1]]<-NSParam2
  .RVM[[length(.RVM)+1]]<-NSTypes
  .RVM[[length(.RVM)+1]]<- -2 * CL + 2 * npar
  .RVM[[length(.RVM)+1]]<- -2 * CL + log(N) * npar

  name1<-names(.RVM)
  name1[(length(.RVM)-4):length(.RVM)]<-c("NSParam","NSParam2","NSfamily","NSAIC","NSBIC")
  names(.RVM)<-name1
  return(.RVM)
}


#' Simulation from Nonstationary Vine Copula
#'
#' @param N Number of d-dimensional observations to simulate.
#' @param RVM An [RVineMatrix()] object containing the information of
#' the R-vine copula model. Optionally, a length-`N` list of
#'   [RVineMatrix()]  objects sharing the same structure, but possibly
#'   different family/parameter can be supplied.
#' @param NSfamily pair-copula family matrix with nonstationary values
#' @param NSpar1,NSpar2 pair-copula parameters matrix with nonstationary values
#' @param U If not [NULL()], an (N,d)-matrix of \eqn{U[0,1]} random
#' variates to be transformed to the copula sample.
#'
#' @return A matrix of the simulated variables from the given nonstationary vine copula model,
#' including the following informations:
#' A  matrix of data simulated from the given nonstationary vine copula model.
#'
#' @import VineCopula
#' @import pracma
#' @export
#' @author Quan Zhang
#' @examples
#'
#' data(dataset)
#' ze1<-CDVineCopulaConditional::CDVineCondListMatrices(dataset, Nx=2, type = "CVine-DVine")
#' v1<-list()
#' l=1
#' AIC1<-vector()
#' for(j in 1:2){
#' for(k in 1:2){
#' rvm1<-VineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=ze1[[j]][[k]])
#' v1[[l]]<-rvm1
#' l<-l+1
#' AIC1<-cbind(AIC1,rvm1$AIC)
#' }
#' }
#' n1<-which(AIC1==min(AIC1))
#' rvm<-v1[[n1[1]]]
#' m2<-NSVineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=rvm$Matrix)
#' m3<-NSVineCopSim(N=300,rvm,NSfamily=m2$NSfamily,NSpar1=m2$NSParam,NSpar2=m2$NSParam2,U=NULL)
#'
NSVineCopSim <- function(N, RVM,NSfamily,NSpar1,NSpar2, U = NULL) {

  set.seed(1234)

  ## sanity checks
  stopifnot(N >= 1)
  if (!is(RVM, "RVineMatrix"))
    stop("'RVM' has to be an RVineMatrix object.")

  ## reorder matrix and U (if provided)
  n <- dim(RVM)
  o <- diag(RVM$Matrix)
  RVM <- VineCopula:::normalizeRVineMatrix(RVM)
  takeU <- !is.null(U)
  if (takeU) {
    if (!is.matrix(U))
      U <- rbind(U, deparse.level = 0L)
    if ((d <- ncol(U)) < 2)
      stop("U should be at least bivariate")  # should be an (N, n) matrix
    U <- U[, rev(o)]
  }

  ## create objects for C-call
  matri <- as.vector(RVM$Matrix)
  w1 <- as.vector(NSfamily)
  maxmat <- as.vector(RVM$MaxMat)
  conindirect <- as.vector(RVM$CondDistr$indirect)
  matri[is.na(matri)] <- 0
  w1[is.na(w1)] <- 0
  maxmat[is.na(maxmat)] <- 0
  conindirect[is.na(conindirect)] <- 0

  size1<-pracma::size(NSpar1)

  out1<-array(0,dim=c(N,size1[2],size1[3]))

  for(i in 1:size1[3]){
    tmp <- rep(0, n * N)

    th <- as.vector(NSpar1[,,i])
    th2 <- as.vector(NSpar2[,,i])

    ## simulate R-Vine
    tmp <- .C("SimulateRVine",
              as.integer(N),
              as.integer(n),
              as.integer(w1),
              as.integer(maxmat),
              as.integer(matri),
              as.integer(conindirect),
              as.double(th),
              as.double(th2),
              as.double(tmp),
              as.double(U),
              as.integer(takeU),
              PACKAGE = "VineCopula")[[9]]

    ## store results, bring back to initial order and return
    out <- matrix(tmp, ncol = n, byrow = TRUE)
    if (!is.null(RVM$names)) {
      colnames(out) <- RVM$names
    }
    out <- out[, sort(o[length(o):1], index.return = TRUE)$ix]

    out1[,,i]<-out
  }

  return(out1)
}

#' Sequential Pair-Copula Selection and Estimation for Vine Copula Models
#'
#' @param data A data matrix. The data of the conditioning variable have to copy the last column of this matrix.
#' @param familyset Vector of nonstationary bivariate copula families to select from.
#' @param Matrix Lower (or upper) triangular d x d matrix that defines the R-vine tree structure.
#' @param selectioncrit Character indicating the criterion for pair-copula selection. Possible choices are "AIC" (default) and "BIC".
#' @param indeptest Logical; whether a hypothesis test for the independence of
#' \code{u1} and \code{u2} is performed before bivariate copula selection
#' (default: \code{indeptest = FALSE}; see \code{BiCopIndTest}).  The
#' independence copula is chosen for a (conditional) pair if the null
#' hypothesis of independence cannot be rejected.
#' @param level numeric; significance level of the independence test (default:
#' \code{level = 0.05}).
#' @param trunclevel integer; level of truncation.
#' @param weights Numerical; weights for each observation (optional).
#' @param rotations logical; if TRUE, all rotations of the families in familyset are included.
#' @param se Logical; whether standard errors are estimated (default: se = FALSE).
#' @param presel Logical; whether to exclude families before fitting based on symmetry properties of the data. Makes the selection about 30\ (on average), but may yield slightly worse results in few special cases.
#' @param method indicates the estimation method: either maximum
#' likelihood estimation (`method = "mle"`; default) or inversion of
#' Kendall's tau (`method = "itau"`). For `method = "itau"` only
#' one parameter families and the Student t copula can be used (`family =
#' 1,2,3,4,5,6,13,14,16,23,24,26,33,34` or `36`). For the t-copula,
#' `par2` is found by a crude profile likelihood optimization over the
#' interval (2, 10].
#' @param cores integer; if `cores > 1`, estimation will be parallelized
#' within each tree (using [foreach::foreach()]). Note that
#' parallelization causes substantial overhead and may be slower than
#' single-threaded computation when dimension, sample size, or family set are
#' small or `method = "itau"`
#'
#' @return An object with the selected vine copula families,
#' including the following information:
#' An [RVineMatrix()] object with the selected families
#' (`family`) as well as sequentially
#' estimated parameters stored in `par` and `par2`.
#' \item{nobs}{number of observations,}
#' \item{logLik, pair.logLik}{log likelihood (overall and pairwise)}
#' \item{AIC, pair.AIC}{Aikaike's Informaton Criterion (overall and pairwise),}
#' \item{BIC, pair.BIC}{Bayesian's Informaton Criterion (overall and pairwise),}
#' \item{emptau}{matrix of empirical values of Kendall's tau,}
#' @importFrom VineCopula BiCopSelect
#' @export
#' @author Quan Zhang
#' @examples
#'
#' data(dataset)
#' ze1<-CDVineCopulaConditional::CDVineCondListMatrices(dataset, Nx=2, type = "CVine-DVine")
#' v1<-list()
#' l=1
#' AIC1<-vector()
#' for(j in 1:2){
#'   for(k in 1:2){
#'     rvm1<-VineCopPar(dataset,familyset=c(1,2,3,4,5),Matrix=ze1[[j]][[k]])
#'     v1[[l]]<-rvm1
#'     l<-l+1
#'     AIC1<-cbind(AIC1,rvm1$AIC)
#'   }
#' }
#' n1<-which(AIC1==min(AIC1))
#' rvm<-v1[[n1[1]]]
#'
VineCopPar <- function(data, familyset = NA, Matrix, selectioncrit = "AIC",
                       indeptest = FALSE, level = 0.05, trunclevel = NA,
                       weights = NA, rotations = FALSE, se = FALSE,
                       presel = FALSE, method = "mle", cores = 1) {
  if (!(selectioncrit %in% c("AIC", "BIC", "logLik")))
    stop("Selection criterion not implemented.")
  if (level < 0 & level > 1)
    stop("Significance level has to be between 0 and 1.")

  d <- n <- ncol(data)
  N <- nrow(data)
  varnames <- colnames(data)
  if (is.na(trunclevel))
    trunclevel <- d

  types <- familyset
  if (trunclevel == 0)
    types <- 0

  M <- Matrix
  Mold <- M
  o <- diag(M)
  M <- VineCopula:::reorderRVineMatrix(M)
  data <- data[, o[length(o):1]]

  MaxMat <- VineCopula:::createMaxMat(M)
  CondDistr <- VineCopula:::neededCondDistr(M)

  Types   <- matrix(0, d, d)
  Params  <- matrix(0, d, d)
  Params2 <- matrix(0, d, d)
  Ses     <- matrix(0, d, d)
  Se2s    <- matrix(0, d, d)
  pvals   <- matrix(0, d, d)
  nobs    <- matrix(0, d, d)
  logLiks <- matrix(0, d, d)

  V <- list()
  V$direct <- array(NA, dim = c(d, N))
  V$indirect <- array(NA, dim = c(d, N))
  V$direct <- t(data[, d:1])

  if (cores != 1 | is.na(cores)) {
    if (is.na(cores))
      cores <- max(1, detectCores() - 1)
    if (cores > 1) {
      cl <- makePSOCKcluster(cores)
      setDefaultCluster(cl)
      on.exit(try(stopCluster(cl), silent = TRUE))
    }
  }

  CL<-0
  warn <- NULL
  for (k in d:2) {

    res.k<-list()

    for(i in 1:(k-1)) {
      if (k > i) {

        m <- MaxMat[k, i]
        zr1 <- V$direct[i, ]

        if (m == M[k, i]) {
          zr2 <-V$direct[(d - m + 1), ]
        } else {
          zr2 <-V$indirect[(d - m + 1), ]
        }

        if (trunclevel <= (d-k))
          familyset <- 0

        na.ind <- which(is.na(zr1 + zr2))
        if (length(na.ind) >= length(zr1) - 10 ||
            (length(familyset) == 1 && familyset == 0)) {
          cfit <- BiCop(0)
          cfit$se  <- NA
          cfit$se2 <- NA
          cfit$nobs   <- 0
          cfit$logLik <- 0
          cfit$AIC    <- 0
          cfit$BIC    <- 0
          cfit$emptau <- NA
          cfit$p.value.indeptest <- NA
          if (length(na.ind) >= length(zr1) - 10) {
            warn <- paste("Insufficient data for at least one pair.",
                          "Independence has been selected automatically.")
          }
        } else {
          cfit <- suppressWarnings(VineCopula::BiCopSelect(u1 = zr2,
                                               u2 = zr1,
                                               familyset = familyset,
                                               selectioncrit = selectioncrit,
                                               indeptest = indeptest,
                                               level = level,
                                               weights = weights,
                                               rotations = rotations,
                                               se = se,
                                               presel = presel,
                                               method = method))

          rhobar1<-cbind(cfit$par,cfit$par2)
          family1<-cfit$family
          warn <- NULL
        }

        direct <- indirect <- NULL
        if (CondDistr$direct[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            direct <- zr1
          } else {
            direct <- suppressWarnings(VineCopula::BiCopHfunc1(zr2,
                                                   zr1,
                                                   cfit,
                                                   check.pars = FALSE))

          }
        }


        if (CondDistr$indirect[k - 1, i]) {
          if (length(familyset) == 1 && familyset == 0) {
            indirect <- zr2
          } else {
            indirect <- suppressWarnings(VineCopula::BiCopHfunc2(zr2,
                                                     zr1,
                                                     cfit,
                                                     check.pars = FALSE))
          }
        }

        res.k[[i]]<-list(direct = direct,
                         indirect = indirect,
                         cfit = cfit,
                         warn = warn)

      } else {
        list(cfit = BiCop(0, 0))
      }
    }

    for (i in seq_len(k - 1)) {
      Types[k, i]   <- res.k[[i]]$cfit$family
      Params[k, i]  <- res.k[[i]]$cfit$par
      Params2[k, i] <- res.k[[i]]$cfit$par2
      tmpse         <- res.k[[i]]$cfit$se
      Ses[k, i]     <- ifelse(is.null(tmpse), NA, tmpse)
      tmpse2        <- res.k[[i]]$cfit$se2
      Se2s[k, i]    <- ifelse(is.null(tmpse2), NA, tmpse2)
      pvals[k, i]   <- res.k[[i]]$cfit$p.value.indeptest
      logLiks[k, i] <- res.k[[i]]$cfit$logLik
      if (!is.null(res.k[[i]]$warn))
        warn <- res.k[[i]]$warn
      if (!is.null(res.k[[i]]$direct)){
        V$direct[i, ] <- res.k[[i]]$direct
      }
      if (!is.null(res.k[[i]]$indirect)){
        V$indirect[i, ] <- res.k[[i]]$indirect
      }

    }
  }

  .RVM <- VineCopula::RVineMatrix(Mold,
                      family = Types,
                      par = Params,
                      par2 = Params2,
                      names = varnames)
  if (se == TRUE) {
    .RVM$se <- Ses
    .RVM$se2 <- Se2s
  }
  .RVM$nobs <- N
  revo <- sapply(1:d, function(i) which(o[length(o):1] == i))
  like <- suppressWarnings(VineCopula::RVineLogLik(data[, revo], .RVM, calculate.V = FALSE))
  .RVM$logLik <- like$loglik
  .RVM$pair.logLik <- logLiks
  npar <- length(which(.RVM$par!=0))+length(which(.RVM$par2!=0))
  .RVM$AIC <- -2 * like$loglik + 2 * npar
  .RVM$BIC <- -2 * like$loglik + log(N) * npar
  .RVM$p.value.indeptest <- pvals

  return(.RVM)
}

